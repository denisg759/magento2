define(
    [
        'jquery',
        'Magento_Checkout/js/model/quote',
    ],
    function ($, quote) {
        'use strict';

        var mixin = {
            getMessage: function () {
                if (quote) {

                    var selectedShippingMethod = quote.shippingMethod();

                    var pickingMessage = window.checkoutConfig.message;

                    document.getElementById("pickup-data").style.width = '60%'; 
                    document.getElementById("pickup-data").style.backgroundColor = "#fcffe6";
                    
                    if (selectedShippingMethod) {
                        var carrierCode = selectedShippingMethod.carrier_code;
                    }
                }
                if (selectedShippingMethod.carrier_code == "pickingshipping") {
                    return pickingMessage;
                }
            }
        };
        return function (target) {
            return target.extend(mixin);
        };
    });

