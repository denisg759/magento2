var config = {

    map: {
        '*': {
            'Magento_Checkout/template/shipping-address/shipping-method-list':'Rocktechnolabs_PickingShipping/template/shipping/shipping-method-list'
        }
    },

    config: {
        mixins: {
            'Magento_Checkout/js/view/shipping': {
                'Rocktechnolabs_PickingShipping/js/view/shipping-mixin': true
            }
        }
    }
};