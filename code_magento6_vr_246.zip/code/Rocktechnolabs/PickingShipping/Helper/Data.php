<?php

namespace Rocktechnolabs\PickingShipping\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    /**
     * Get Config Data
     *
     * @param Magento\Store\Model\ScopeInterface
     */
    public function getMessage()
    {
        return $this->scopeConfig->getValue(
            "carriers/pickingshipping/pickingmessage",
            ScopeInterface::SCOPE_STORE
        );
    }
}
