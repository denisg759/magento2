<?php
namespace Rocktechnolabs\PickingShipping\Model;

use Magento\Checkout\Model\ConfigProviderInterface;

class ConfigProvider implements ConfigProviderInterface
{
    /**
     * @var $helper
     */
    protected $helper;

    /**
     * @param \Rocktechnolabs\PickingShipping\Helper\Data $helper
     */
    public function __construct(
        \Rocktechnolabs\PickingShipping\Helper\Data $helper
    ) {
        $this->helper = $helper;
    }

    /**
     * Config Data
     *
     * @return String
     */
    public function getConfig()
    {
        $message = $this->helper->getMessage();

        $config = [];
        $config['message'] = $message;

        return $config;
    }
}
