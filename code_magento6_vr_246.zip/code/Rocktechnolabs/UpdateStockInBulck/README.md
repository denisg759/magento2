# Magento 2 - update product stock in bulk using api 

#csv 
  CSV File Header
    -sku
    -qty
