<?php
namespace Rocktechnolabs\UpdateStockInBulck\Api;

interface StockUpdateInterface
{
    /**
     * Updates Product Stock In Bulck.
     *
     * @api
     * @param mixed $data
     * @return mixed
     */
    public function updateStock($data);
}
