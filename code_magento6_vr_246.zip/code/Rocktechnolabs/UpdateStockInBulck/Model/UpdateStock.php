<?php
namespace Rocktechnolabs\UpdateStockInBulck\Model;

use Rocktechnolabs\UpdateStockInBulck\Api\StockUpdateInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Exception\LocalizedException;

class UpdateStock implements StockUpdateInterface
{
    /**
     * @var $productRepository
     */
    protected $stockRegistry;
   
    /**
     * @var $filesystem
     */
    protected $filesystem;

    /**
     * @var $file
     */
    protected $file;

    /**
     * @var $csv
     */
    protected $csv;

    /**
     * @param \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry
     * @param \Magento\Framework\Filesystem $filesystem
     * @param \Magento\Framework\Filesystem\Driver\File $file
     * @param \Magento\Framework\File\Csv $csv
     */
    public function __construct(
        \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Filesystem\Driver\File $file,
        \Magento\Framework\File\Csv $csv
    ) {
        $this->stockRegistry = $stockRegistry;
        $this->filesystem = $filesystem;
        $this->file = $file;
        $this->csv = $csv;
    }

    /**
     * Update Product Stock In Bulk.
     *
     * @api
     * @param mixed $data
     * @return mixed
     */
    public function updateStock($data)
    {
        $media = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
        $updatedCount = 0;
        if (empty($data)) {
            return false;
        }
        if (is_string($data)) {
            $path = $media.$data;
            if (!$this->file->isExists($path)) {
                return "file ".$data." doesn't exist";
            }
            $csvdata = $this->csv->getData($path);
            $header = array_shift($csvdata);
            $skukey = array_search("sku", $header);
            $qtykey = array_search("qty", $header);
        } else {
            $csvdata = $data;
            $skukey = "sku";
            $qtykey = "qty";
        }
        
        foreach ($csvdata as $value) {
            $sku = $value[$skukey];
            $qty = $value[$qtykey];
            try {
                  $stockItem = $this->stockRegistry->getStockItemBySku($sku);
                  $stockItem->setQty($qty);
                  $this->stockRegistry->updateStockItemBySku($sku, $stockItem);
                  $updatedCount++;
            } catch (LocalizedException $e) {
                  return "Error updating stock for SKU: $sku - " . $e->getMessage();
            }
        }
        return $updatedCount." products stock updated success fully";
    }
}
