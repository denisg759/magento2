var config = {
    paths: {
        owlcarousel: "Rocktechnolabs_Slider/js/owl.carousel.min",
    },
    shim: {
        owlcarousel: {
            deps: ['jquery']
        }
    }
};