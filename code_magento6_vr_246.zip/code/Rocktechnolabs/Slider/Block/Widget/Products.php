<?php
namespace Rocktechnolabs\Slider\Block\Widget;

use Magento\Framework\DataObject\IdentityInterface;
use Magento\Widget\Block\BlockInterface;
use Magento\Framework\App\ActionInterface;
use Magento\Catalog\Block\Product\Context;
use Magento\Catalog\Model\ProductRepository;
use Magento\Framework\Url\Helper\Data;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;

class Products extends \Magento\Catalog\Block\Product\AbstractProduct implements BlockInterface
{
    /**
     * Data helper
     *
     * @var \Magento\Framework\Url\Helper\Data
     */
    protected $urlHelper;

    /**
     * productRepository variable
     *
     * @var [type]
     */
    protected $_productRepository;
    
     /**
      * template variable
      * @var string
      */
    protected $_template = "Widget/Slider.phtml";

    protected $customerSessionFactory;

    /**
     * @param Context $context
     * @param ProductRepository $productRepository
     * @param Data $urlHelper
     * @param CollectionFactory $productCollectionFactory
     * @param array $data = []
     **/
    public function __construct(
        Context $context,
        \Magento\Customer\Model\SessionFactory $customerSessionFactory,
        ProductRepository $productRepository,
        Data $urlHelper,
        CollectionFactory $productCollectionFactory,
        array $data = []
    ) {
        $this->_productRepository = $productRepository;
        $this->_productCollectionFactory = $productCollectionFactory;
        $this->urlHelper = $urlHelper;
        $this->customerSessionFactory = $customerSessionFactory;
        parent::__construct($context, $data);
    }

    /**
     * Load Products collection
     *
     * @param  array $skus
     */
    public function getProductCollection($skus)
    {
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->addAttributeToFilter('sku', ['in' =>$skus]);
        
        return $collection;
    }

     /**
      * Get post parameters
      *
      * @param \Magento\Catalog\Model\Product $product
      * @return array
      */
    public function getAddToCartPostParams(\Magento\Catalog\Model\Product $product)
    {
        $url = $this->getAddToCartUrl($product, ['_escape' => false]);
        return [
            'action' => $url,
            'data' => [
                'product' => (int) $product->getEntityId(),
                ActionInterface::PARAM_NAME_URL_ENCODED =>
                    $this->urlHelper->getEncodedUrl($url),
            ]
        ];
    }

    public function Customer()
    {
         $customer = $this->customerSessionFactory ->create();
        if($customer->isLoggedIn())
        {
            return true;
        }
    }
}
