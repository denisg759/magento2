# Magento 2 - update product stock in bulk using api 

#CSV File Header For Order Id 
    Header => "OrderId"
    
