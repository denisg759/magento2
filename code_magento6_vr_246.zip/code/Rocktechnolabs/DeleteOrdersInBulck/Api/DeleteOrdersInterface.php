<?php
namespace Rocktechnolabs\DeleteOrdersInBulck\Api;

interface DeleteOrdersInterface
{
    /**
     * Delete Order In Bulk.
     *
     * @api
     * @param mixed $data
     * @return mixed
     */
    public function deleteOrders($data);
}
