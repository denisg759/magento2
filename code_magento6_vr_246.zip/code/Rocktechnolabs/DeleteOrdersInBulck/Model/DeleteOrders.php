<?php
namespace Rocktechnolabs\DeleteOrdersInBulck\Model;

use Rocktechnolabs\DeleteOrdersInBulck\Api\DeleteOrdersInterface;
use Magento\Framework\App\Filesystem\DirectoryList;

class DeleteOrders implements DeleteOrdersInterface
{
    /**
     * @var $order
     */
    protected $order;
                                 
    /**
     * @var $fileSystem
     */
    protected $fileSystem;

    /**
     * @var $file
     */
    protected $file;

    /**
     * @var $csv
     */
    protected $csv;

    /**
     * @param \Magento\Sales\Api\Data\OrderInterface $order
     * @param \Magento\Framework\Filesystem $fileSystem
     * @param \Magento\Framework\Filesystem\Driver\File $file
     * @param \Magento\Framework\File\Csv $csv
     */
    public function __construct(
        \Magento\Sales\Api\Data\OrderInterface $order,
        \Magento\Framework\Filesystem $fileSystem,
        \Magento\Framework\Filesystem\Driver\File $file,
        \Magento\Framework\File\Csv $csv
    ) {
        $this->order = $order;
        $this->fileSystem = $fileSystem;
        $this->file = $file;
        $this->csv = $csv;
    }

    /**
     * Delete Order In Bulk.
     *
     * @api
     * @param mixed $data
     * @return mixed
     */
    public function deleteOrders($data)
    {
        if (empty($data)) {
            return false;
        }

        if (is_string($data)) {
            $media = $this->fileSystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
            $path = $media.$data;

            if (!$this->file->isExists($path)) {
                return "File ".$data." Doesn't Exist";
            }

            $csvData = $this->csv->getData($path);
            $header = array_shift($csvData);
            $orderIdKey = array_search("OrderId", $header);
        } else {
            $csvData = $data;
            $orderIdKey = "OrderId";
        }

        $updatedCount = 0;
        $notExistOrder = "";
        $deleteOrders = "";

        foreach ($csvData as $id) {
            $orderId = $id[$orderIdKey];
            $order = $this->order->loadByIncrementId($orderId);
            $getOrderId = $order->getIncrementId();

            if ($getOrderId !== $orderId) {
                $invalidIds[] = $orderId;
                $notExistOrder = "Order with ID ".implode(",", $invalidIds)." doesn't exist";
            } else {
                $order->delete();
                $updatedCount++;
                $deleteOrders = $updatedCount." Order Deleted Successfully. ";
            }
        }
        return $deleteOrders." ".$notExistOrder;
    }
}
