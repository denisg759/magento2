<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Rocktechnolabs_DeleteOrdersInBulck',
    __DIR__
);
