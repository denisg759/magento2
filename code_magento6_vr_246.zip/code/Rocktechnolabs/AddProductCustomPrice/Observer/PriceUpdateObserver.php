<?php
namespace Rocktechnolabs\AddProductCustomPrice\Observer;

use Magento\Framework\Event\ObserverInterface;

class PriceUpdateObserver implements ObserverInterface
{
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $item = $observer->getEvent()->getData('quote_item');
        $product = $observer->getEvent()->getData('product');
        $price = $product->getData('product_price_attribute');

        $item->setCustomPrice($price);
        $item->setOriginalCustomPrice($price);
        $item->getProduct()->setIsSuperMode(true);

    }
}
