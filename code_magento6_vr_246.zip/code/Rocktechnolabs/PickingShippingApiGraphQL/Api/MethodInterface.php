<?php
namespace Rocktechnolabs\PickingShippingApiGraphQL\Api;
 
interface MethodInterface
{
    /**
     * GET ShippingMethod
     *
     * @param string $shippingMethod
     * @return string
     */
    public function getData($shippingMethod);
}
