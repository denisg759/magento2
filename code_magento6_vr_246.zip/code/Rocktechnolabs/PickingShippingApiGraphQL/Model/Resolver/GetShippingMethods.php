<?php
namespace Rocktechnolabs\PickingShippingApiGraphQL\Model\Resolver;

use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;

class GetShippingMethods implements ResolverInterface
{
    /**
     * Shipconfig variable
     *
     * @var $shipconfig
     */
    protected $shipConfig;

    /**
     * Config
     *
     * @param \Magento\Shipping\Model\Config $shipConfig
     */
    public function __construct(
        \Magento\Shipping\Model\Config $shipConfig
    ) {
        $this->shipConfig = $shipConfig;
    }

    /**
     * Resolv Function
     *
     * @param Field $field
     * @param \Magento\Framework\GraphQl\Query\Resolver\ContextInterface $context
     * @param ResolveInfo $info
     * @param array|null $value
     * @param array|null $args
     * @return array|\Magento\Framework\GraphQl\Query\Resolver\Value|mixed
     * @throws GraphQlInputException
     */
    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {

        $activeCarriers = $this->shipConfig->getActiveCarriers();

        $shippingMethods = $this->shipConfig->getAllCarriers();

        $shippingMethod = $args['method'];
        $shippingMethodExists = isset($activeCarriers[$shippingMethod]);

        $pickingmessage = null;
        if ($shippingMethod == "pickingshipping") {
            $pickingmessage = $shippingMethods[$shippingMethod]->getConfigData("pickingmessage");
        }

        $output = [];

        if ($shippingMethodExists) {
            $output["message"] = $pickingmessage;
        } else {
            $output["message"] = "shipping method doesn't exist";
        }
        return $output;
    }
}
