<?php
namespace Rocktechnolabs\PickingShippingApiGraphQL\Model;

use Rocktechnolabs\PickingShippingApiGraphQL\Api\MethodInterface;

class GetMethod implements MethodInterface
{
    /**
     * Shipping variable
     *
     * @var $_shipping
     */
    protected $_shipConfig;

    /**
     * ScopeConfig variable
     *
     * @var $_shipping
     */
    protected $_scopeConfig;

    /**
     * Configs
     *
     * @param \Magento\Shipping\Model\Config $shipConfig
     */
    public function __construct(
        \Magento\Shipping\Model\Config $shipConfig
    ) {
        $this->_shipConfig = $shipConfig;
    }

    /**
     * Shipping Method
     *
     * @param String $shippingMethod
     */
    public function getData($shippingMethod)
    {
        $activeCarriers = $this->_shipConfig->getActiveCarriers();

        $shippingMethods = $this->_shipConfig->getAllCarriers();

        $pickingmessage = null;
        if ($shippingMethod == "pickingshipping") {
            $pickingmessage = $shippingMethods[$shippingMethod]->getConfigData("pickingmessage");
        }

        $shippingMethodExists = isset($activeCarriers[$shippingMethod]);

        if ($shippingMethodExists) {
            return $pickingmessage;
        } else {
            return "shipping method doesn't exist";
        }
    }
}
