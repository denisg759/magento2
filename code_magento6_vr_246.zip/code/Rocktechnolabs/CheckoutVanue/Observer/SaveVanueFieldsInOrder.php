<?php
namespace Rocktechnolabs\CheckoutVanue\Observer;

use Magento\Framework\Event\ObserverInterface;
 
class SaveVanueFieldsInOrder implements ObserverInterface
{
   /**
    * Observer
    *
    * @param \Magento\Framework\Event\Observer $observer
    */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        $quote = $observer->getEvent()->getQuote();

        $order->setData('vanue', $quote->getVanue());

        return $this;
    }
}
