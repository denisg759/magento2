<?php
namespace Rocktechnolabs\RegisterCustomerAddtocart\ViewModel;

class Session implements \Magento\Framework\View\Element\Block\ArgumentInterface
{

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
     protected $_customerSession;

    /**
     * CustomerSession
     *
     * @param \Magento\Customer\Model\SessionFactory     $customerSession
     */
    public function __construct(
        \Magento\Customer\Model\SessionFactory $customerSession
    ) {
        $this->_customerSession = $customerSession;
    }

     /**
      * CustomerSession
      *
      * @param \Magento\Customer\Model\SessionFactory    $customerSession
      */
    public function getCustomer()
    {
        $customer = $this->_customerSession->create();
        if ($customer->isLoggedIn()) {
            return true;
        }
    }
}
