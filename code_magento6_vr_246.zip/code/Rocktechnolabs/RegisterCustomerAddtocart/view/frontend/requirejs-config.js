var config = {
   map: {
     '*': {
      'Magento_Catalog/js/product/addtocart-button': 'Rocktechnolabs_RegisterCustomerAddtocart/js/product/addtocart-button'
    }
}};