<?php
namespace Rocktechnolabs\RegisterCustomerAddtocart\Plugin;

use Magento\Catalog\Model\Product;

class Hidecartbutton
{
    /**
     * Session
     * @var $_customerSessionFactory
     */
    protected $_customerSessionFactory;

   /**
    * @param Magento\Customer\Model\SessionFactory $customerSessionFactory
    */
    public function __construct(
        \Magento\Customer\Model\SessionFactory $customerSessionFactory
    ) {
        $this->_customerSessionFactory = $customerSessionFactory;
    }

    /**
     * Session
     *
     * @param Magento\Catalog\Model\Product $product
     * @param Magento\Catalog\Model\Product $isSaleable
     */
    public function afterIsSaleable(Product $product, $isSaleable)
    {
        $customerSession = $this->_customerSessionFactory->create();
        if ($customerSession->isLoggedIn()) {
            return $product->isSalable();
        } else {
            return 0;
        }
    }
}
