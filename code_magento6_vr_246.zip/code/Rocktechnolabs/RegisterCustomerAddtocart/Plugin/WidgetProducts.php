<?php
namespace Rocktechnolabs\RegisterCustomerAddtocart\Plugin;

use Magento\CatalogWidget\Block\Product\ProductsList;

class WidgetProducts
{
     /**
      * @var \Magento\Customer\Model\CustomerFactory
      */
     protected $_customerSession;

    /**
     * @var StoreManagerInterface
     */
   /**
    * @var Url
    */
    private $customerUrl;

    /**
     * CustomerSession
     * @param \Magento\Customer\Model\SessionFactory     $customerSession
     * @param \Magento\Customer\Model\Url                $customerUrl
     */
    public function __construct(
        \Magento\Customer\Model\SessionFactory $customerSession,
        \Magento\Customer\Model\Url $customerUrl
    ) {
        $this->_customerSession = $customerSession;
        $this->customerUrl = $customerUrl;
    }
      
     /**
      * Login
      *
      * @param Magento\CatalogWidget\Block\Product\ProductsList $subject
      * @param Magento\CatalogWidget\Block\Product\ProductsList $result
      * @param Magento\CatalogWidget\Block\Product\ProductsList $product
      */
    public function afterGetProductDetailsHtml(
        ProductsList $subject,
        $result,
        $product
    ) {
        $loginUrl = $this->customerUrl->getLoginUrl();
        $RegisterUrl = $this->customerUrl->getRegisterUrl();
        $customLinkHtml = '<P>Please<a href="' . $loginUrl. '"> Login </a> or <a href="'.
        $RegisterUrl.'" >Register </a> to buy this product! </p>';

        $customer = $this->_customerSession->create();
        if (!$customer->isLoggedIn()) {
            return $result . $customLinkHtml;
        }
    }
}
