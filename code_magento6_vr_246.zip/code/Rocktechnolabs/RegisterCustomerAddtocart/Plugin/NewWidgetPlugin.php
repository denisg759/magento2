<?php
namespace Rocktechnolabs\RegisterCustomerAddtocart\Plugin;

class NewWidgetPlugin
{
    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
     protected $_customerSession;

    /**
     * @var Url
     */
     private $customerUrl;

    /**
     * CustomerSession
     * @param \Magento\Customer\Model\SessionFactory  $customerSession
     * @param \Magento\Customer\Model\Url             $customerUrl
     */
    public function __construct(
        \Magento\Customer\Model\SessionFactory $customerSession,
        \Magento\Customer\Model\Url $customerUrl
    ) {
        $this->_customerSession = $customerSession;
        $this->customerUrl = $customerUrl;
    }
   
   /**
    * NewWidget
    *
    * @param \Magento\Catalog\Block\Product\Widget\NewWidget $subject
    * @param \Magento\Catalog\Block\Product\Widget\NewWidget $result
    * @param \Magento\Catalog\Block\Product\Widget\NewWidget $product
    */
    public function aftergetProductPriceHtml(
        \Magento\Catalog\Block\Product\Widget\NewWidget $subject,
        $result,
        $product
    ) {
        $loginUrl = $this->customerUrl->getLoginUrl();
        $RegisterUrl = $this->customerUrl->getRegisterUrl();
        $customLinkHtml = '<P>Please<a href="' . $loginUrl. '"> Login </a> or <a href="'.
        $RegisterUrl.'" >Register </a> to buy this product! </p>';
        
        $customer = $this->_customerSession->create();
        if (!$customer->isLoggedIn()) {
            return $result . $customLinkHtml;
        }
    }
}
