<?php
namespace Rocktechnolabs\RegisterCustomerAddtocart\Plugin;

use Magento\Catalog\Block\Product\ListProduct;

class ProductListPlugin
{
    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
     protected $_customerSession;

    /**
     * @var Url
     */
     private $customerUrl;

    /**
     * CustomerSession
     *
     * @param \Magento\Customer\Model\SessionFactory  $customerSession
     * @param \Magento\Customer\Model\Url             $customerUrl
     */
    public function __construct(
        \Magento\Customer\Model\SessionFactory $customerSession,
        \Magento\Customer\Model\Url $customerUrl
    ) {
        $this->_customerSession = $customerSession;
        $this->customerUrl = $customerUrl;
    }

    /**
     * LoginLink
     *
     * @param Magento\Catalog\Block\Product\ListProduct $subject
     * @param Magento\Catalog\Block\Product\ListProduct $result
     * @param Magento\Catalog\Block\Product\ListProduct $product
     */
    public function afterGetProductDetailsHtml(
        ListProduct $subject,
        $result,
        $product
    ) {
           $loginUrl = $this->customerUrl->getLoginUrl();
        $RegisterUrl = $this->customerUrl->getRegisterUrl();
        $customLinkHtml = '<P>Please<a href="' . $loginUrl. '"> Login </a> or <a href="'.
        $RegisterUrl.'" >Register </a> to buy this product! </p>';

         $customer = $this->_customerSession->create();
        if (!$customer->isLoggedIn()) {
            return $result . $customLinkHtml;
        }
    }
}
