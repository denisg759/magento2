require(['jquery', 'jquery/ui' ,'qtychange'], function($){
	});