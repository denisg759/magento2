var config = {
    map: {
        '*': {
            'Magento_Checkout/template/minicart/item/default.html': 'Rocktechnolabs_QtyAddIncrementDecrement/template/minicart/item/default.html',
             qtychange: 'Rocktechnolabs_QtyAddIncrementDecrement/js/minicart/qtychange'
        }
    }
};